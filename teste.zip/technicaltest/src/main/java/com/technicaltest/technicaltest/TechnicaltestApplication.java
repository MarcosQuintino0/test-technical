package com.technicaltest.technicaltest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechnicaltestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechnicaltestApplication.class, args);

	}

}
