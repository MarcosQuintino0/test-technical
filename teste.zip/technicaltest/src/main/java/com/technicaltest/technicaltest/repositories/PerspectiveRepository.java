package com.technicaltest.technicaltest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technicaltest.technicaltest.entities.Perspective;

public interface PerspectiveRepository extends JpaRepository<Perspective, Long>{

}
