package com.technicaltest.technicaltest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technicaltest.technicaltest.entities.Objective;

public interface ObjectiveRepository extends JpaRepository<Objective, Long>{

}
