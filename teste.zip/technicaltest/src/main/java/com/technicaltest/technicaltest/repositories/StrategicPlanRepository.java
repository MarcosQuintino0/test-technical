package com.technicaltest.technicaltest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technicaltest.technicaltest.entities.StrategicPlan;

public interface StrategicPlanRepository extends JpaRepository<StrategicPlan, Long>{

}
